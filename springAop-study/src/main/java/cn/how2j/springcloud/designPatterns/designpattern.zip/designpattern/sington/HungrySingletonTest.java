package cn.how2j.springcloud.designpattern.sington;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

/**
 * @author Jinbiao
 * @date 2022/4/1
 * @apiNote
 */
public class HungrySingletonTest {



    public static void main(String[] args) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException, NoSuchFieldException {
//        Class<HungrySingleton> hungrySingletonClass = HungrySingleton.class;  //这样不会输出静态代码块的输出语句
//        System.out.println(HungrySingleton.name);

        //通过类加载来获取实例
        HungrySingleton instance = HungrySingleton.getInstance();

        //通过反射获取实例
        Constructor<HungrySingleton> declaredConstructor = HungrySingleton.class.getDeclaredConstructor();
        declaredConstructor.setAccessible(true);
        HungrySingleton hungrySingleton = declaredConstructor.newInstance();

        System.out.println(instance==hungrySingleton);

    }
}
class  HungrySingleton{     //饿汉模式

    static {
        System.out.println("HungrySingleton init");
    }
    public static String name="Jinbiao";

    private Integer age=23;

    private static HungrySingleton instance=new HungrySingleton();

    private HungrySingleton(){
                if(instance!=null){
                    throw new RuntimeException("单例不允许多个实例。。");
                }
    }
    public static HungrySingleton getInstance(){
        return instance;
    }
}
