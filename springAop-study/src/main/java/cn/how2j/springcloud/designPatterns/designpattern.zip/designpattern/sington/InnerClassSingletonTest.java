package cn.how2j.springcloud.designpattern.sington;

/**
 * @author Jinbiao
 * @date 2022/4/1
 * @apiNote
 */
public class InnerClassSingletonTest {
    public static void main(String[] args) {
//        System.out.println(InnerClassSingleton.name); //内部类SingletonHolder并不会初始化
        System.out.println(InnerClassSingleton.getInstance()); //只有在真正调用getInstance()才会初始化,  饿汉模式和懒汉模式的结合
    }
}

class InnerClassSingleton{

    public static String name="Jinbiao";

    static {
        System.out.println("InnerClassSingleton init");
    }
    private static class SingletonHolder{
        static {
            System.out.println("SingletonHolder init");
        }
        private static InnerClassSingleton instance=new InnerClassSingleton();
    }
    private InnerClassSingleton(){

    }
    public static InnerClassSingleton getInstance(){
        return SingletonHolder.instance;
    }
}

class A{
    public static void main(String[] args) {
//        System.out.println(InnerClassSingleton.name); //内部类SingletonHolder并不会初始化
        System.out.println(InnerClassSingleton.getInstance()); //单例模式,  获取实例的时候都是同一个
    }
}
